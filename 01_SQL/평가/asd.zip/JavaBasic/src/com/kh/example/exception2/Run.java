package com.kh.example.exception2;

public class Run {

	public static void main(String[] args) {
		new NumberMenu().menu();

	}

}
