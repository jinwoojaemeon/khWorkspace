package com.kh.example.oop5;

public class Run {

	public static void main(String[] args) {
		SnackMenu s = new SnackMenu();

		s.menu();
	}

}
