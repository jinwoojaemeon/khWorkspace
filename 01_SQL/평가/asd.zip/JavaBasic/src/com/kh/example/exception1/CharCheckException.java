package com.kh.example.exception1;

public class CharCheckException extends Exception {
	public CharCheckException() {
		super();
	}

	public CharCheckException(String message) {
		super(message);
	}
	
}
