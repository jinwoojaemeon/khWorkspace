package com.kh.example.abstractNInterface;

public interface CellPhone {
	public abstract String charge();
}
