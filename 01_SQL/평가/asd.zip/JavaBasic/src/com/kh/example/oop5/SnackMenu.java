package com.kh.example.oop5;

import java.util.Scanner;

public class SnackMenu {
	Scanner sc = new Scanner(System.in);
	SnackController scr = new SnackController();
	
	public void menu() {
		System.out.println("스낵류를 입력하세요.");
		System.out.print("종류 입력:");
		String kind = sc.next();
		System.out.print("이름 입력:");
		String name = sc.next();
		System.out.print("맛 입력:");
		String flavor = sc.next();
		System.out.print("개수 입력:");
		int numOf = sc.nextInt();
		System.out.print("가격 입력:");
		int price = sc.nextInt();
		scr.saveData(kind, name, flavor, numOf, price);
		System.out.println("저장 완료되었습니다.");
		
		System.out.print("저장한 정보를 확인하시겠습니까?(y,n) : ");
		
		char check = sc.next().toLowerCase().charAt(0);
		if(check == 'y') {
			System.out.println(scr.confirmData());
		}
		else{
			return;
		}
		
	}
}
