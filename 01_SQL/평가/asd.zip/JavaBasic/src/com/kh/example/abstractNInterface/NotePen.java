package com.kh.example.abstractNInterface;

public interface NotePen {
	static final boolean PEN_BUTTON = true;
	public abstract boolean bluetoothPen();
}
