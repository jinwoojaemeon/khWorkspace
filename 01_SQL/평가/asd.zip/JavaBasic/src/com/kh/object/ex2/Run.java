package com.kh.object.ex2;

public class Run {
	public static void main(String[] args) {
		BankAccount ac1 = new BankAccount(0);
		BankAccount ac2 = ac1;    // ac2, ac1은 모두 같은 주소를 참조하고 있다.
		
		ac1.deposit(5000);
		ac2.withdraw(1000);
		ac1.checkMyBalance();
		
		ac2 = new BankAccount(0);
		ac2.deposit(5000);
		
		ac1.transfer(ac2, 1000);
		ac1.checkMyBalance();
		ac2.checkMyBalance();
	}
}
