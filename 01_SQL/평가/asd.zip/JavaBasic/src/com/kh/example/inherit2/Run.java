package com.kh.example.inherit2;

public class Run {

	public static void main(String[] args) {
		new PersonMenu().mainMenu();
	}

}
