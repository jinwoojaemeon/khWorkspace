package operator;
import java.util.Scanner;   // ctrl, shift  o? 
public class Operator1 {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		/*
		 * 1. 논리부정 연산자
		 * 논리값 true/false를 반대로 변경하는 연산자 .
		 */
		System.out.println("true의 부정 : " + !(true));
		System.out.println("false의 부정 : " + !(false));
		
		System.out.println("값1: ");
		int num1 = sc.nextInt();
		
		System.out.println("값2: ");
		int num2 = sc.nextInt();
		
		System.out.println("값1 > 값2 : " + (num1 > num2));
		sc.close();
	}

}
