package com.kh.example.oop2;

public class Run {

	public static void main(String[] args) {
		Student std = new Student();
		std.information();

	}

}
