package com.project.lifegame.run;

import com.project.lifegame.view.LobbyMenu;

public class Run {
	public static void main(String[] args) {
		new LobbyMenu().lobbyMenu();
	}
}
