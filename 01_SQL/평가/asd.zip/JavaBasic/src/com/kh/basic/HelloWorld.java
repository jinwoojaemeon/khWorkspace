package com.kh.basic;

public class HelloWorld {
	// 한 줄 주석 /*여러 줄 주석*/
	
	//main method : 자바코드의 실행을 담당 
	public static void main(String[] args) {
		System.out.println("Hello, world!");
	}
}
