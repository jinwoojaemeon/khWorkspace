package com.kh.example.abstractNInterface;

public interface Camera {
	public abstract String picture();
}
