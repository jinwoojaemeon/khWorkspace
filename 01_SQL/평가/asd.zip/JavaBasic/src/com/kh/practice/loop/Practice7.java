package com.kh.practice.loop;

public class Practice7 {

	public static void main(String[] args) {
		for(int dan = 2; dan <= 9; dan++) {
			for(int i=1;i<=9;i++) {
				System.out.println(dan + " * " +i  +" = "+ dan*i);
			}
		}
	}

}
