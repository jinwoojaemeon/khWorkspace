package com.kh.example.abstractNInterface;

public interface TouchDisplay {
	public abstract String touch();
}
