package com.kh.example.collection2;

public class Run {

	public static void main(String[] args) {
		new LotteryMenu().mainMenu();
	}

}
