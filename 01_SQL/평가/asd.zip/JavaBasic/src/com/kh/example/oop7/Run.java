package com.kh.example.oop7;

public class Run {
	public static void main(String[] args) {
		ProductMenu pm = new ProductMenu();
		pm.mainMenu();
	}
}
