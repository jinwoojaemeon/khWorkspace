package com.kh.interface1;

public interface Animal {
	public abstract void speak();
	public abstract void move();
}
