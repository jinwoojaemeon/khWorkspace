package com.kh.example.inherit;

public class Run {

	public static void main(String[] args) {
		new PointMenu().mainMenu();
	}

}
