package com.kh.example.oop4;

import java.util.Scanner;

public class Run {
	public static void main(String[] args) {
		ShapeMenu shapeM = new ShapeMenu();
		shapeM.inputMenu();
		
	}

}
