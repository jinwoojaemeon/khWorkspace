package review.basic;

public class In {
	public static void main(String[] args) {
		double dNum01 = 0.1, dNum11 = 1.1, dNum12 = 1.2;
		boolean isSame = (dNum01+dNum11)==dNum12;
		System.out.println(isSame);
	}
}
